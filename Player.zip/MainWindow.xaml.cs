﻿using KitX.Core;
using System;
using System.Collections.Generic;
using System.ComponentModel.Composition;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Player
{
    /// <summary>
    /// MainWindow.xaml 的交互逻辑
    /// </summary>
    [Export(typeof(IContract))]
    public partial class MainWindow : Window, IContract
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private string WorkBase = null;

        public void SetWorkBase(string path)
        {
            WorkBase = path;
            if (!Directory.Exists(WorkBase))
            {
                Directory.CreateDirectory(WorkBase);
            }
        }

        public string GetDescribe_Complex()
        {
            return "多媒体播放器，支持多种格式，当前功能仍不完善，仍在升级维护中。";
        }

        public string GetDescribe_Simple()
        {
            return "简单的多媒体播放器";
        }

        public string GetFileName()
        {
            return "Player.dll";
        }

        public string GetHelpLink()
        {
            return "http://docs.catrol.cn/";
        }

        public string GetHostLink()
        {
            return "http://www.catrol.cn/";
        }

        public BitmapImage GetIcon()
        {
            return FindResource("Icon") as BitmapImage;
        }

        public Languages GetLang()
        {
            return Languages.zh_CN;
        }

        public string GetName()
        {
            return "Player";
        }

        public string GetPublisher()
        {
            return "Catrol";
        }

        public string GetVersion()
        {
            return "Alpha";
        }

        public Window GetWindow()
        {
            return new MainWindow();
        }

        public void SetTheme(Theme theme)
        {
            Background = theme == Theme.Light ? new SolidColorBrush(Colors.WhiteSmoke) : new SolidColorBrush(Colors.Black);
            Foreground = theme == Theme.Light ? new SolidColorBrush(Colors.Black) : new SolidColorBrush(Colors.WhiteSmoke);
        }

        QuickView quicker = new QuickView();

        public UserControl GetQuickView()
        {
            quicker.win = win;
            if (started)
            {
                return quicker;
            }
            else
            {
                return null;
            }
        }

        MainWindow win;
        bool started = false;

        public void Start()
        {
            if (!started)
            {
                win = new MainWindow();
                win.Closed += (x, y) => started = false;
                win.Show();
                started = true;
            }
            else
            {
                if (win.Visibility == Visibility.Hidden)
                {
                    win.Visibility = Visibility.Visible;
                }
                else
                {
                    win.Visibility = Visibility.Hidden;
                }
            }
        }

        public void End()
        {
            win.Close();
            started = false;
        }

        public Tags GetTag()
        {
            return Tags.Normal;
        }
    }
}
