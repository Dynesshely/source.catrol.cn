﻿namespace UNAUP
{
    partial class Form
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.panel1 = new System.Windows.Forms.Panel();
            this.button7 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.button8 = new System.Windows.Forms.Button();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.button2 = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.开始ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.刷新ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.添加一个组件ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.删除该用户信息ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.修改目前登录用户信息ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator5 = new System.Windows.Forms.ToolStripSeparator();
            this.退出密码管理大师ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.导出该用户登录密码ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.查看该用户登录密码ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.删除本地文件ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.获取本次使用期间的最高权限ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.文档ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.添加配置文件ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.删除配置文件ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.降配置文件同步至云端ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.关于ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.密码管理大师ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.创作组ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator6 = new System.Windows.Forms.ToolStripSeparator();
            this.激活信息ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.button6 = new System.Windows.Forms.Button();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.panel5 = new System.Windows.Forms.Panel();
            this.button5 = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.panel6 = new System.Windows.Forms.Panel();
            this.label11 = new System.Windows.Forms.Label();
            this.button9 = new System.Windows.Forms.Button();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.panel7 = new System.Windows.Forms.Panel();
            this.panel8 = new System.Windows.Forms.Panel();
            this.label17 = new System.Windows.Forms.Label();
            this.progressBar2 = new System.Windows.Forms.ProgressBar();
            this.button15 = new System.Windows.Forms.Button();
            this.label16 = new System.Windows.Forms.Label();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.progressBar1 = new System.Windows.Forms.ProgressBar();
            this.button14 = new System.Windows.Forms.Button();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.button10 = new System.Windows.Forms.Button();
            this.label12 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.button11 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            this.panel9 = new System.Windows.Forms.Panel();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.button16 = new System.Windows.Forms.Button();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.linkLabel1 = new System.Windows.Forms.LinkLabel();
            this.linkLabel2 = new System.Windows.Forms.LinkLabel();
            this.linkLabel3 = new System.Windows.Forms.LinkLabel();
            this.panel10 = new System.Windows.Forms.Panel();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.button17 = new System.Windows.Forms.Button();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.panel11 = new System.Windows.Forms.Panel();
            this.panel12 = new System.Windows.Forms.Panel();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.重置密码大师ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator7 = new System.Windows.Forms.ToolStripSeparator();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            this.panel10.SuspendLayout();
            this.panel11.SuspendLayout();
            this.panel12.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.button7);
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.radioButton1);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.textBox1);
            this.panel1.Controls.Add(this.textBox2);
            this.panel1.Location = new System.Drawing.Point(5, 5);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(305, 474);
            this.panel1.TabIndex = 0;
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(244, 436);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(51, 23);
            this.button7.TabIndex = 7;
            this.button7.Text = "☼退出";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("微软雅黑 Light", 11F);
            this.button1.Location = new System.Drawing.Point(195, 206);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(82, 31);
            this.button1.TabIndex = 6;
            this.button1.Text = "登录";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Font = new System.Drawing.Font("微软雅黑 Light", 10F);
            this.radioButton1.Location = new System.Drawing.Point(83, 209);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(83, 24);
            this.radioButton1.TabIndex = 5;
            this.radioButton1.TabStop = true;
            this.radioButton1.Text = "记住密码";
            this.radioButton1.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("微软雅黑 Light", 16F);
            this.label3.Location = new System.Drawing.Point(20, 18);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(57, 30);
            this.label3.TabIndex = 4;
            this.label3.Text = "登录";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("微软雅黑 Light", 12F);
            this.label2.Location = new System.Drawing.Point(3, 150);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(74, 21);
            this.label2.TabIndex = 3;
            this.label2.Text = "登录密码";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("微软雅黑 Light", 12F);
            this.label1.Location = new System.Drawing.Point(3, 67);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(74, 21);
            this.label1.TabIndex = 2;
            this.label1.Text = "账户名称";
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("微软雅黑 Light", 12F);
            this.textBox1.Location = new System.Drawing.Point(83, 64);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(212, 29);
            this.textBox1.TabIndex = 0;
            // 
            // textBox2
            // 
            this.textBox2.Font = new System.Drawing.Font("微软雅黑 Light", 12F);
            this.textBox2.Location = new System.Drawing.Point(83, 147);
            this.textBox2.Name = "textBox2";
            this.textBox2.PasswordChar = '∷';
            this.textBox2.Size = new System.Drawing.Size(212, 29);
            this.textBox2.TabIndex = 1;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.button8);
            this.panel2.Controls.Add(this.radioButton2);
            this.panel2.Controls.Add(this.button2);
            this.panel2.Controls.Add(this.label7);
            this.panel2.Controls.Add(this.textBox5);
            this.panel2.Controls.Add(this.label5);
            this.panel2.Controls.Add(this.label6);
            this.panel2.Controls.Add(this.textBox3);
            this.panel2.Controls.Add(this.textBox4);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Location = new System.Drawing.Point(5, 5);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(305, 474);
            this.panel2.TabIndex = 1;
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(20, 436);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(75, 23);
            this.button8.TabIndex = 15;
            this.button8.Text = "取消";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Font = new System.Drawing.Font("微软雅黑 Light", 10F);
            this.radioButton2.Location = new System.Drawing.Point(91, 290);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(97, 24);
            this.radioButton2.TabIndex = 7;
            this.radioButton2.TabStop = true;
            this.radioButton2.Text = "创建后登录";
            this.radioButton2.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("微软雅黑 Light", 11F);
            this.button2.Location = new System.Drawing.Point(204, 287);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(82, 31);
            this.button2.TabIndex = 14;
            this.button2.Text = "创建";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("微软雅黑 Light", 12F);
            this.label7.Location = new System.Drawing.Point(3, 232);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(74, 21);
            this.label7.TabIndex = 13;
            this.label7.Text = "二级密码";
            // 
            // textBox5
            // 
            this.textBox5.Font = new System.Drawing.Font("微软雅黑 Light", 12F);
            this.textBox5.Location = new System.Drawing.Point(83, 229);
            this.textBox5.Name = "textBox5";
            this.textBox5.PasswordChar = '∷';
            this.textBox5.Size = new System.Drawing.Size(212, 29);
            this.textBox5.TabIndex = 12;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("微软雅黑 Light", 12F);
            this.label5.Location = new System.Drawing.Point(3, 150);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(74, 21);
            this.label5.TabIndex = 11;
            this.label5.Text = "登录密码";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("微软雅黑 Light", 12F);
            this.label6.Location = new System.Drawing.Point(3, 67);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(74, 21);
            this.label6.TabIndex = 10;
            this.label6.Text = "账户名称";
            // 
            // textBox3
            // 
            this.textBox3.Font = new System.Drawing.Font("微软雅黑 Light", 12F);
            this.textBox3.Location = new System.Drawing.Point(83, 64);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(212, 29);
            this.textBox3.TabIndex = 8;
            // 
            // textBox4
            // 
            this.textBox4.Font = new System.Drawing.Font("微软雅黑 Light", 12F);
            this.textBox4.Location = new System.Drawing.Point(83, 147);
            this.textBox4.Name = "textBox4";
            this.textBox4.PasswordChar = '∷';
            this.textBox4.Size = new System.Drawing.Size(212, 29);
            this.textBox4.TabIndex = 9;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("微软雅黑 Light", 16F);
            this.label4.Location = new System.Drawing.Point(28, 18);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(57, 30);
            this.label4.TabIndex = 7;
            this.label4.Text = "创建";
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.button4);
            this.panel3.Controls.Add(this.button3);
            this.panel3.Controls.Add(this.flowLayoutPanel1);
            this.panel3.Controls.Add(this.menuStrip1);
            this.panel3.Location = new System.Drawing.Point(5, 5);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(305, 474);
            this.panel3.TabIndex = 2;
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(220, 447);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(75, 23);
            this.button4.TabIndex = 3;
            this.button4.Text = "添加组件";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(8, 447);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 23);
            this.button3.TabIndex = 2;
            this.button3.Text = "删除组件";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowLayoutPanel1.Location = new System.Drawing.Point(0, 25);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(305, 449);
            this.flowLayoutPanel1.TabIndex = 5;
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.开始ToolStripMenuItem,
            this.文档ToolStripMenuItem,
            this.关于ToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(305, 25);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // 开始ToolStripMenuItem
            // 
            this.开始ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.刷新ToolStripMenuItem,
            this.添加一个组件ToolStripMenuItem,
            this.删除该用户信息ToolStripMenuItem,
            this.toolStripSeparator1,
            this.修改目前登录用户信息ToolStripMenuItem,
            this.toolStripSeparator5,
            this.退出密码管理大师ToolStripMenuItem,
            this.toolStripSeparator2,
            this.导出该用户登录密码ToolStripMenuItem,
            this.查看该用户登录密码ToolStripMenuItem,
            this.删除本地文件ToolStripMenuItem,
            this.toolStripSeparator4,
            this.获取本次使用期间的最高权限ToolStripMenuItem,
            this.toolStripSeparator7,
            this.重置密码大师ToolStripMenuItem});
            this.开始ToolStripMenuItem.Name = "开始ToolStripMenuItem";
            this.开始ToolStripMenuItem.Size = new System.Drawing.Size(44, 21);
            this.开始ToolStripMenuItem.Text = "开始";
            // 
            // 刷新ToolStripMenuItem
            // 
            this.刷新ToolStripMenuItem.Name = "刷新ToolStripMenuItem";
            this.刷新ToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F5;
            this.刷新ToolStripMenuItem.Size = new System.Drawing.Size(232, 22);
            this.刷新ToolStripMenuItem.Text = "刷新";
            this.刷新ToolStripMenuItem.Click += new System.EventHandler(this.刷新ToolStripMenuItem_Click);
            // 
            // 添加一个组件ToolStripMenuItem
            // 
            this.添加一个组件ToolStripMenuItem.Name = "添加一个组件ToolStripMenuItem";
            this.添加一个组件ToolStripMenuItem.Size = new System.Drawing.Size(232, 22);
            this.添加一个组件ToolStripMenuItem.Text = "退出登录";
            this.添加一个组件ToolStripMenuItem.Click += new System.EventHandler(this.添加一个组件ToolStripMenuItem_Click);
            // 
            // 删除该用户信息ToolStripMenuItem
            // 
            this.删除该用户信息ToolStripMenuItem.Name = "删除该用户信息ToolStripMenuItem";
            this.删除该用户信息ToolStripMenuItem.Size = new System.Drawing.Size(232, 22);
            this.删除该用户信息ToolStripMenuItem.Text = "删除该用户信息";
            this.删除该用户信息ToolStripMenuItem.Click += new System.EventHandler(this.删除该用户信息ToolStripMenuItem_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(229, 6);
            // 
            // 修改目前登录用户信息ToolStripMenuItem
            // 
            this.修改目前登录用户信息ToolStripMenuItem.Name = "修改目前登录用户信息ToolStripMenuItem";
            this.修改目前登录用户信息ToolStripMenuItem.Size = new System.Drawing.Size(232, 22);
            this.修改目前登录用户信息ToolStripMenuItem.Text = "修改目前登录用户信息";
            // 
            // toolStripSeparator5
            // 
            this.toolStripSeparator5.Name = "toolStripSeparator5";
            this.toolStripSeparator5.Size = new System.Drawing.Size(229, 6);
            // 
            // 退出密码管理大师ToolStripMenuItem
            // 
            this.退出密码管理大师ToolStripMenuItem.Name = "退出密码管理大师ToolStripMenuItem";
            this.退出密码管理大师ToolStripMenuItem.Size = new System.Drawing.Size(232, 22);
            this.退出密码管理大师ToolStripMenuItem.Text = "退出密码管理大师";
            this.退出密码管理大师ToolStripMenuItem.Click += new System.EventHandler(this.退出密码管理大师ToolStripMenuItem_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(229, 6);
            // 
            // 导出该用户登录密码ToolStripMenuItem
            // 
            this.导出该用户登录密码ToolStripMenuItem.Name = "导出该用户登录密码ToolStripMenuItem";
            this.导出该用户登录密码ToolStripMenuItem.Size = new System.Drawing.Size(232, 22);
            this.导出该用户登录密码ToolStripMenuItem.Text = "导出为本地密码文件";
            this.导出该用户登录密码ToolStripMenuItem.Click += new System.EventHandler(this.导出该用户登录密码ToolStripMenuItem_Click);
            // 
            // 查看该用户登录密码ToolStripMenuItem
            // 
            this.查看该用户登录密码ToolStripMenuItem.Name = "查看该用户登录密码ToolStripMenuItem";
            this.查看该用户登录密码ToolStripMenuItem.Size = new System.Drawing.Size(232, 22);
            this.查看该用户登录密码ToolStripMenuItem.Text = "查看本地密码文件";
            this.查看该用户登录密码ToolStripMenuItem.Click += new System.EventHandler(this.查看该用户登录密码ToolStripMenuItem_Click);
            // 
            // 删除本地文件ToolStripMenuItem
            // 
            this.删除本地文件ToolStripMenuItem.Name = "删除本地文件ToolStripMenuItem";
            this.删除本地文件ToolStripMenuItem.Size = new System.Drawing.Size(232, 22);
            this.删除本地文件ToolStripMenuItem.Text = "删除本地密码文件";
            this.删除本地文件ToolStripMenuItem.Click += new System.EventHandler(this.删除本地文件ToolStripMenuItem_Click);
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(229, 6);
            // 
            // 获取本次使用期间的最高权限ToolStripMenuItem
            // 
            this.获取本次使用期间的最高权限ToolStripMenuItem.Name = "获取本次使用期间的最高权限ToolStripMenuItem";
            this.获取本次使用期间的最高权限ToolStripMenuItem.Size = new System.Drawing.Size(232, 22);
            this.获取本次使用期间的最高权限ToolStripMenuItem.Text = "获取本次使用期间的最高权限";
            this.获取本次使用期间的最高权限ToolStripMenuItem.Click += new System.EventHandler(this.获取本次使用期间的最高权限ToolStripMenuItem_Click);
            // 
            // 文档ToolStripMenuItem
            // 
            this.文档ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.添加配置文件ToolStripMenuItem,
            this.删除配置文件ToolStripMenuItem,
            this.toolStripSeparator3,
            this.降配置文件同步至云端ToolStripMenuItem});
            this.文档ToolStripMenuItem.Name = "文档ToolStripMenuItem";
            this.文档ToolStripMenuItem.Size = new System.Drawing.Size(44, 21);
            this.文档ToolStripMenuItem.Text = "文档";
            // 
            // 添加配置文件ToolStripMenuItem
            // 
            this.添加配置文件ToolStripMenuItem.Name = "添加配置文件ToolStripMenuItem";
            this.添加配置文件ToolStripMenuItem.Size = new System.Drawing.Size(196, 22);
            this.添加配置文件ToolStripMenuItem.Text = "添加配置文件";
            // 
            // 删除配置文件ToolStripMenuItem
            // 
            this.删除配置文件ToolStripMenuItem.Name = "删除配置文件ToolStripMenuItem";
            this.删除配置文件ToolStripMenuItem.Size = new System.Drawing.Size(196, 22);
            this.删除配置文件ToolStripMenuItem.Text = "删除配置文件";
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(193, 6);
            // 
            // 降配置文件同步至云端ToolStripMenuItem
            // 
            this.降配置文件同步至云端ToolStripMenuItem.Name = "降配置文件同步至云端ToolStripMenuItem";
            this.降配置文件同步至云端ToolStripMenuItem.Size = new System.Drawing.Size(196, 22);
            this.降配置文件同步至云端ToolStripMenuItem.Text = "将配置文件同步至云端";
            // 
            // 关于ToolStripMenuItem
            // 
            this.关于ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.密码管理大师ToolStripMenuItem,
            this.创作组ToolStripMenuItem,
            this.toolStripSeparator6,
            this.激活信息ToolStripMenuItem});
            this.关于ToolStripMenuItem.Name = "关于ToolStripMenuItem";
            this.关于ToolStripMenuItem.Size = new System.Drawing.Size(44, 21);
            this.关于ToolStripMenuItem.Text = "关于";
            // 
            // 密码管理大师ToolStripMenuItem
            // 
            this.密码管理大师ToolStripMenuItem.Name = "密码管理大师ToolStripMenuItem";
            this.密码管理大师ToolStripMenuItem.Size = new System.Drawing.Size(165, 22);
            this.密码管理大师ToolStripMenuItem.Text = "密码管理大师(...)";
            this.密码管理大师ToolStripMenuItem.Click += new System.EventHandler(this.密码管理大师ToolStripMenuItem_Click);
            // 
            // 创作组ToolStripMenuItem
            // 
            this.创作组ToolStripMenuItem.Name = "创作组ToolStripMenuItem";
            this.创作组ToolStripMenuItem.Size = new System.Drawing.Size(165, 22);
            this.创作组ToolStripMenuItem.Text = "创作组(...)";
            this.创作组ToolStripMenuItem.Click += new System.EventHandler(this.创作组ToolStripMenuItem_Click);
            // 
            // toolStripSeparator6
            // 
            this.toolStripSeparator6.Name = "toolStripSeparator6";
            this.toolStripSeparator6.Size = new System.Drawing.Size(162, 6);
            // 
            // 激活信息ToolStripMenuItem
            // 
            this.激活信息ToolStripMenuItem.Name = "激活信息ToolStripMenuItem";
            this.激活信息ToolStripMenuItem.Size = new System.Drawing.Size(165, 22);
            this.激活信息ToolStripMenuItem.Text = "激活信息";
            this.激活信息ToolStripMenuItem.Click += new System.EventHandler(this.激活信息ToolStripMenuItem_Click);
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.label9);
            this.panel4.Controls.Add(this.label8);
            this.panel4.Controls.Add(this.button6);
            this.panel4.Controls.Add(this.textBox7);
            this.panel4.Controls.Add(this.textBox6);
            this.panel4.Location = new System.Drawing.Point(5, 485);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(305, 107);
            this.panel4.TabIndex = 3;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(43, 52);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(29, 12);
            this.label9.TabIndex = 8;
            this.label9.Text = "密码";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(7, 15);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(65, 12);
            this.label8.TabIndex = 7;
            this.label8.Text = "自定义字段";
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(220, 76);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(75, 23);
            this.button6.TabIndex = 6;
            this.button6.Text = "完成";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // textBox7
            // 
            this.textBox7.Location = new System.Drawing.Point(94, 49);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(201, 21);
            this.textBox7.TabIndex = 1;
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(94, 12);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(201, 21);
            this.textBox6.TabIndex = 0;
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.button5);
            this.panel5.Controls.Add(this.label10);
            this.panel5.Controls.Add(this.textBox8);
            this.panel5.Location = new System.Drawing.Point(5, 599);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(305, 69);
            this.panel5.TabIndex = 4;
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(220, 41);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(75, 23);
            this.button5.TabIndex = 9;
            this.button5.Text = "完成";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(19, 17);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(53, 12);
            this.label10.TabIndex = 10;
            this.label10.Text = "二级密码";
            // 
            // textBox8
            // 
            this.textBox8.Location = new System.Drawing.Point(94, 14);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(201, 21);
            this.textBox8.TabIndex = 9;
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.label11);
            this.panel6.Controls.Add(this.button9);
            this.panel6.Controls.Add(this.textBox9);
            this.panel6.Location = new System.Drawing.Point(5, 674);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(305, 56);
            this.panel6.TabIndex = 5;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(18, 6);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(101, 12);
            this.label11.TabIndex = 2;
            this.label11.Text = "删除第几行的组件";
            // 
            // button9
            // 
            this.button9.Location = new System.Drawing.Point(220, 30);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(75, 23);
            this.button9.TabIndex = 1;
            this.button9.Text = "确认删除";
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // textBox9
            // 
            this.textBox9.Location = new System.Drawing.Point(130, 3);
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(165, 21);
            this.textBox9.TabIndex = 0;
            // 
            // panel7
            // 
            this.panel7.Controls.Add(this.panel8);
            this.panel7.Controls.Add(this.progressBar1);
            this.panel7.Controls.Add(this.button14);
            this.panel7.Controls.Add(this.label15);
            this.panel7.Controls.Add(this.label14);
            this.panel7.Controls.Add(this.label13);
            this.panel7.Controls.Add(this.button10);
            this.panel7.Controls.Add(this.label12);
            this.panel7.Controls.Add(this.pictureBox2);
            this.panel7.Controls.Add(this.pictureBox1);
            this.panel7.Location = new System.Drawing.Point(326, 5);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(945, 663);
            this.panel7.TabIndex = 6;
            // 
            // panel8
            // 
            this.panel8.Controls.Add(this.label17);
            this.panel8.Controls.Add(this.progressBar2);
            this.panel8.Controls.Add(this.button15);
            this.panel8.Controls.Add(this.label16);
            this.panel8.Controls.Add(this.pictureBox3);
            this.panel8.Location = new System.Drawing.Point(517, 487);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(380, 100);
            this.panel8.TabIndex = 9;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("微软雅黑 Light", 9.5F);
            this.label17.Location = new System.Drawing.Point(106, 45);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(100, 19);
            this.label17.TabIndex = 12;
            this.label17.Text = "没有更多信息了";
            // 
            // progressBar2
            // 
            this.progressBar2.Location = new System.Drawing.Point(110, 89);
            this.progressBar2.Name = "progressBar2";
            this.progressBar2.Size = new System.Drawing.Size(271, 3);
            this.progressBar2.TabIndex = 10;
            // 
            // button15
            // 
            this.button15.Location = new System.Drawing.Point(302, 34);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(75, 23);
            this.button15.TabIndex = 11;
            this.button15.Text = "下载并安装";
            this.button15.UseVisualStyleBackColor = true;
            this.button15.Click += new System.EventHandler(this.button15_Click);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("微软雅黑 Light", 10F);
            this.label16.Location = new System.Drawing.Point(106, 13);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(137, 20);
            this.label16.TabIndex = 10;
            this.label16.Text = "密码管理大师v2.1.4+\r\n";
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::UNAUP.Used._05f155fb37d5ed1102857a297cdf51c9;
            this.pictureBox3.Location = new System.Drawing.Point(12, 13);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(79, 79);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 0;
            this.pictureBox3.TabStop = false;
            // 
            // progressBar1
            // 
            this.progressBar1.Location = new System.Drawing.Point(605, 629);
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Size = new System.Drawing.Size(326, 28);
            this.progressBar1.TabIndex = 8;
            // 
            // button14
            // 
            this.button14.Font = new System.Drawing.Font("微软雅黑 Light", 12F);
            this.button14.Location = new System.Drawing.Point(469, 628);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(139, 30);
            this.button14.TabIndex = 7;
            this.button14.Text = "检查更新";
            this.button14.UseVisualStyleBackColor = true;
            this.button14.Click += new System.EventHandler(this.button14_Click);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("微软雅黑 Light", 16F);
            this.label15.Location = new System.Drawing.Point(512, 356);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(321, 60);
            this.label15.TabIndex = 6;
            this.label15.Text = "感谢您对密码管理大师的信任，\r\n感谢您使用密码管理大师。\r\n";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("微软雅黑 Light", 13F);
            this.label14.Location = new System.Drawing.Point(513, 98);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(0, 24);
            this.label14.TabIndex = 5;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("微软雅黑 Light", 16F);
            this.label13.Location = new System.Drawing.Point(512, 206);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(409, 120);
            this.label13.TabIndex = 4;
            this.label13.Text = "在version2.1.4Beta中增加了6个重载位，\r\n将开启速度再次优化，同时加入了全局快\r\n捷键，快速呼出主界面来进行登录。或者\r\n是想起密码。";
            // 
            // button10
            // 
            this.button10.Location = new System.Drawing.Point(0, 0);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(75, 23);
            this.button10.TabIndex = 3;
            this.button10.Text = "button10";
            this.button10.UseVisualStyleBackColor = true;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("微软雅黑 Light", 22F);
            this.label12.Location = new System.Drawing.Point(489, 25);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(197, 39);
            this.label12.TabIndex = 2;
            this.label12.Text = "密码管理大师";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::UNAUP.Used.p2;
            this.pictureBox2.Location = new System.Drawing.Point(0, 311);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(463, 352);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 1;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::UNAUP.Used.p1;
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(463, 314);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // button11
            // 
            this.button11.Font = new System.Drawing.Font("微软雅黑 Light", 12F);
            this.button11.Location = new System.Drawing.Point(409, 680);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(155, 43);
            this.button11.TabIndex = 7;
            this.button11.Text = "关于密码管理大师";
            this.button11.UseVisualStyleBackColor = true;
            this.button11.Click += new System.EventHandler(this.button11_Click);
            // 
            // button12
            // 
            this.button12.Font = new System.Drawing.Font("微软雅黑 Light", 12F);
            this.button12.Location = new System.Drawing.Point(684, 680);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(155, 43);
            this.button12.TabIndex = 8;
            this.button12.Text = "关于创作组";
            this.button12.UseVisualStyleBackColor = true;
            this.button12.Click += new System.EventHandler(this.button12_Click);
            // 
            // button13
            // 
            this.button13.Font = new System.Drawing.Font("微软雅黑 Light", 12F);
            this.button13.Location = new System.Drawing.Point(964, 680);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(155, 43);
            this.button13.TabIndex = 9;
            this.button13.Text = "激活信息";
            this.button13.UseVisualStyleBackColor = true;
            this.button13.Click += new System.EventHandler(this.button13_Click);
            // 
            // panel9
            // 
            this.panel9.Controls.Add(this.linkLabel3);
            this.panel9.Controls.Add(this.linkLabel2);
            this.panel9.Controls.Add(this.linkLabel1);
            this.panel9.Controls.Add(this.label19);
            this.panel9.Controls.Add(this.label18);
            this.panel9.Controls.Add(this.pictureBox4);
            this.panel9.Location = new System.Drawing.Point(326, 5);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(945, 663);
            this.panel9.TabIndex = 10;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox4.Image = global::UNAUP.Used._5588b6c6ef582877938f12c01f14339e;
            this.pictureBox4.Location = new System.Drawing.Point(0, 0);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(945, 663);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 0;
            this.pictureBox4.TabStop = false;
            // 
            // button16
            // 
            this.button16.Location = new System.Drawing.Point(1196, 693);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(75, 23);
            this.button16.TabIndex = 11;
            this.button16.Text = "<-隐藏";
            this.button16.UseVisualStyleBackColor = true;
            this.button16.Click += new System.EventHandler(this.button16_Click);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.BackColor = System.Drawing.Color.Transparent;
            this.label18.Font = new System.Drawing.Font("微软雅黑 Light", 32F);
            this.label18.Location = new System.Drawing.Point(46, 80);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(240, 57);
            this.label18.TabIndex = 1;
            this.label18.Text = "纸屑工作室";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.BackColor = System.Drawing.Color.Transparent;
            this.label19.Font = new System.Drawing.Font("微软雅黑 Light", 32F);
            this.label19.Location = new System.Drawing.Point(46, 180);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(328, 57);
            this.label19.TabIndex = 2;
            this.label19.Text = "Scraps of Paper";
            // 
            // linkLabel1
            // 
            this.linkLabel1.AutoSize = true;
            this.linkLabel1.Font = new System.Drawing.Font("微软雅黑 Light", 15F);
            this.linkLabel1.Location = new System.Drawing.Point(51, 346);
            this.linkLabel1.Name = "linkLabel1";
            this.linkLabel1.Size = new System.Drawing.Size(192, 27);
            this.linkLabel1.TabIndex = 3;
            this.linkLabel1.TabStop = true;
            this.linkLabel1.Text = "访问纸屑工作室官网";
            this.linkLabel1.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel1_LinkClicked);
            // 
            // linkLabel2
            // 
            this.linkLabel2.AutoSize = true;
            this.linkLabel2.Font = new System.Drawing.Font("微软雅黑 Light", 15F);
            this.linkLabel2.Location = new System.Drawing.Point(51, 461);
            this.linkLabel2.Name = "linkLabel2";
            this.linkLabel2.Size = new System.Drawing.Size(212, 27);
            this.linkLabel2.TabIndex = 4;
            this.linkLabel2.TabStop = true;
            this.linkLabel2.Text = "访问密码管理大师官网";
            this.linkLabel2.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel2_LinkClicked);
            // 
            // linkLabel3
            // 
            this.linkLabel3.AutoSize = true;
            this.linkLabel3.Font = new System.Drawing.Font("微软雅黑 Light", 15F);
            this.linkLabel3.Location = new System.Drawing.Point(51, 576);
            this.linkLabel3.Name = "linkLabel3";
            this.linkLabel3.Size = new System.Drawing.Size(212, 27);
            this.linkLabel3.TabIndex = 5;
            this.linkLabel3.TabStop = true;
            this.linkLabel3.Text = "看看纸屑们还做过什么";
            this.linkLabel3.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel3_LinkClicked);
            // 
            // panel10
            // 
            this.panel10.Controls.Add(this.panel11);
            this.panel10.Controls.Add(this.panel12);
            this.panel10.Location = new System.Drawing.Point(326, 5);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(945, 663);
            this.panel10.TabIndex = 12;
            // 
            // textBox10
            // 
            this.textBox10.Font = new System.Drawing.Font("宋体", 15F);
            this.textBox10.Location = new System.Drawing.Point(337, 125);
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(386, 30);
            this.textBox10.TabIndex = 0;
            // 
            // textBox11
            // 
            this.textBox11.Font = new System.Drawing.Font("宋体", 15F);
            this.textBox11.Location = new System.Drawing.Point(337, 228);
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new System.Drawing.Size(386, 30);
            this.textBox11.TabIndex = 1;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("微软雅黑 Light", 19F);
            this.label20.Location = new System.Drawing.Point(50, 45);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(223, 35);
            this.label20.TabIndex = 2;
            this.label20.Text = "激活您的密码大师";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("微软雅黑 Light", 19F);
            this.label21.Location = new System.Drawing.Point(145, 119);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(93, 35);
            this.label21.TabIndex = 3;
            this.label21.Text = "注册名";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("微软雅黑 Light", 19F);
            this.label22.Location = new System.Drawing.Point(150, 222);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(93, 35);
            this.label22.TabIndex = 4;
            this.label22.Text = "注册码";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(335, 180);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(275, 12);
            this.label23.TabIndex = 5;
            this.label23.Text = "注册名的格式为xxx（只能为字符串），无字数限制\r\n";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(335, 294);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(293, 24);
            this.label24.TabIndex = 6;
            this.label24.Text = "注册名的格式为xxxxxxxx,无字数限制,只能为整数类型\r\n\r\n";
            // 
            // button17
            // 
            this.button17.Font = new System.Drawing.Font("微软雅黑 Light", 19F);
            this.button17.Location = new System.Drawing.Point(400, 384);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(153, 46);
            this.button17.TabIndex = 7;
            this.button17.Text = "激活!";
            this.button17.UseVisualStyleBackColor = true;
            this.button17.Click += new System.EventHandler(this.button17_Click);
            // 
            // richTextBox1
            // 
            this.richTextBox1.Location = new System.Drawing.Point(122, 480);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(711, 163);
            this.richTextBox1.TabIndex = 8;
            this.richTextBox1.Text = "";
            // 
            // panel11
            // 
            this.panel11.Controls.Add(this.label20);
            this.panel11.Controls.Add(this.richTextBox1);
            this.panel11.Controls.Add(this.label21);
            this.panel11.Controls.Add(this.button17);
            this.panel11.Controls.Add(this.label22);
            this.panel11.Controls.Add(this.label24);
            this.panel11.Controls.Add(this.textBox10);
            this.panel11.Controls.Add(this.textBox11);
            this.panel11.Controls.Add(this.label23);
            this.panel11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel11.Location = new System.Drawing.Point(0, 0);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(945, 663);
            this.panel11.TabIndex = 9;
            // 
            // panel12
            // 
            this.panel12.Controls.Add(this.label27);
            this.panel12.Controls.Add(this.label26);
            this.panel12.Controls.Add(this.label25);
            this.panel12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel12.Location = new System.Drawing.Point(0, 0);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(945, 663);
            this.panel12.TabIndex = 13;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("微软雅黑 Light", 42F);
            this.label25.ForeColor = System.Drawing.Color.Red;
            this.label25.Location = new System.Drawing.Point(70, 79);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(816, 75);
            this.label25.TabIndex = 0;
            this.label25.Text = "您的密码管理大师已经激活成功";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("微软雅黑 Light", 31F);
            this.label26.ForeColor = System.Drawing.Color.Red;
            this.label26.Location = new System.Drawing.Point(46, 318);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(864, 55);
            this.label26.TabIndex = 1;
            this.label26.Text = "感谢使用纸屑工作室倾情制作的密码管理大师\r\n";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("微软雅黑 Light", 31F);
            this.label27.ForeColor = System.Drawing.Color.Red;
            this.label27.Location = new System.Drawing.Point(25, 521);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(906, 55);
            this.label27.TabIndex = 2;
            this.label27.Text = "更多纸屑出品请参见创作组面板来进入网站查询\r\n";
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // 重置密码大师ToolStripMenuItem
            // 
            this.重置密码大师ToolStripMenuItem.Name = "重置密码大师ToolStripMenuItem";
            this.重置密码大师ToolStripMenuItem.Size = new System.Drawing.Size(232, 22);
            this.重置密码大师ToolStripMenuItem.Text = "重置密码大师";
            this.重置密码大师ToolStripMenuItem.Click += new System.EventHandler(this.重置密码大师ToolStripMenuItem_Click);
            // 
            // toolStripSeparator7
            // 
            this.toolStripSeparator7.Name = "toolStripSeparator7";
            this.toolStripSeparator7.Size = new System.Drawing.Size(229, 6);
            // 
            // Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1283, 735);
            this.Controls.Add(this.panel10);
            this.Controls.Add(this.button16);
            this.Controls.Add(this.panel9);
            this.Controls.Add(this.button13);
            this.Controls.Add(this.button12);
            this.Controls.Add(this.button11);
            this.Controls.Add(this.panel7);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "密码管理大师";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form_FormClosing);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel9.ResumeLayout(false);
            this.panel9.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            this.panel10.ResumeLayout(false);
            this.panel11.ResumeLayout(false);
            this.panel11.PerformLayout();
            this.panel12.ResumeLayout(false);
            this.panel12.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem 开始ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 添加一个组件ToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem 修改目前登录用户信息ToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator5;
        private System.Windows.Forms.ToolStripMenuItem 退出密码管理大师ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 文档ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 添加配置文件ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 删除配置文件ToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripMenuItem 关于ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 密码管理大师ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 创作组ToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator6;
        private System.Windows.Forms.ToolStripMenuItem 激活信息ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 删除该用户信息ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 降配置文件同步至云端ToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripMenuItem 导出该用户登录密码ToolStripMenuItem;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.ToolStripMenuItem 查看该用户登录密码ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 删除本地文件ToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStripMenuItem 获取本次使用期间的最高权限ToolStripMenuItem;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.ToolStripMenuItem 刷新ToolStripMenuItem;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.ProgressBar progressBar1;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.ProgressBar progressBar2;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.LinkLabel linkLabel3;
        private System.Windows.Forms.LinkLabel linkLabel2;
        private System.Windows.Forms.LinkLabel linkLabel1;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator7;
        private System.Windows.Forms.ToolStripMenuItem 重置密码大师ToolStripMenuItem;
    }
}

